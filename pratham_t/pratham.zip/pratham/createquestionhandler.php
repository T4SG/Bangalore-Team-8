	<?php
	session_start(); // Starting Session
	$error=''; // Variable To Store Error Message
	if (isset($_POST['submit'])) {
		//echo "Hello";
	if (empty($_POST['Course_Name']) || empty($_POST['Question_Id']) || empty($_POST['Question_Name'])  || empty($_POST['Options']) || empty($_POST['Answer'])) {
	$error = "Some fields are empty";
	echo "some fields are empty";
}
	else
	{
	// Define $username and $password
	$Course_Name=$_POST['Course_Name'];
	$Question_Id=$_POST['Question_Id'];
	$Question_Name=$_POST['Question_Name'];
	$Options=$_POST['Options'];
	$Answer=$_POST['Answer'];
	
	// Establishing Connection with Server by passing server_name, user_id and password as a parameter
	$connection = mysql_connect("localhost", "root", "root");
	// To protect MySQL injection for Security purpose
	$Course_Name= stripslashes($Course_Name);
	$Question_Id= stripslashes($Question_Id);
	$Question_Name = stripslashes($Question_Name);
	$Options= stripslashes($Options);
	$Answer = stripslashes($Answer);
	
	$Course_Name= mysql_real_escape_string($Course_Name);
	$Question_Id= mysql_real_escape_string($Question_Id);
	$Question_Name=mysql_real_escape_string($Question_Name);
	$Options= mysql_real_escape_string($Options);
	$Answer=mysql_real_escape_string($Answer);
	
	
	
	
	
	
	$db = mysql_select_db("edupedia", $connection);
	
	mysql_query("insert into question values('$Course_Name','$Question_Id','$Question_Name','$Options','$Answer')",$connection);
	 echo '<META HTTP-EQUIV="Refresh" Content="0; URL=course.php">';
	
	
	
	
	
	// Selecting Database
	
	mysql_close($connection); // Closing Connection
	}	
	}
	?>
	
