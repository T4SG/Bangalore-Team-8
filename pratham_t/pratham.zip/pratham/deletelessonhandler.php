<?php
session_start();
$cid=$_SESSION['cid'];
$les=$_POST['lesname'];
$connection=mysql_connect("localhost","root","root");
$db = mysql_select_db("edupedia", $connection);
mysql_query("delete from $cid where lesson_name='$les'", $connection);
mysql_query("delete from lesson where lesson_name='$les'",$connection);
		if (!unlink($les.'.php'))
	  {
	  echo ("Error deleting $file lesson");
	  }
	else
	  {
	  echo ("Deleted". $les.".php");
	  }
	  
	  if (!unlink('extras/'.$les.'.php'))
	  {
	  echo ("Error deleting $file lesson");
	  }
	else
	  {
	  echo ("Deleted". $les.".php");
	  }
	  echo '<META HTTP-EQUIV="Refresh" Content="0; URL=course.php">';

?>
