
<?php
session_start(); // Starting Session

$imgflag='none';
$logflag='visible';
$adminflag=0;
$adflag='none';
if(isset($_SESSION['login_user'])){

$imgflag='visible';	
$logflag='none';
include('session.php');
	if(!strcmp($login_session,"admin"))
	{
		$adminflag=1;
		$adflag='visible';
	}
}
$connection = mysql_connect("localhost", "root", "root");
$db = mysql_select_db("edupedia", $connection);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
   <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge">-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Courses</title>
    <!-- Bootstrap Core CSS -->
    
    <!-- Custom CSS -->
    <link href="css/simple-sidebar.css" rel="stylesheet">
	<link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME ICONS  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
     <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
   
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>

    <section class="menu-section" >
        <div class="container">
            <div class="row" >
                <div class="col-md-12" >
                    <div class="navbar-collapse collapse ">
						<ul id="menu-top" class="nav navbar-nav navbar-left">
							<div class="media">
                               <a class="media-left" href="#">
                                    <img src="logo-tab.jpg" class="img-thumbnail" alt="logo" width="120" height="20">
                               </a>
							</div>	
						</ul>
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
							<li><a  href="index.php">Welcome</a></li>
                            <li><a class="menu-top-active" href="course.php">Courses</a></li>
                            <li><a href="login.php"style="display:<?php echo $logflag?>;">Login</a></li> 
							<li><a href="registration.php"style="display:<?php echo $logflag?>;">Registration</a></li> 
							<li class="dropdown" style="display:<?php echo $imgflag?>;">
								<a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
									<span class="glyphicon glyphicon-user" style="font-size: 15px;"></span>
								</a>
								<div class="dropdown-menu dropdown-settings">
                                <div class="media">
                                    <a class="media-left" href="#">
                                  <?php echo '<img src="'. $login_image.'" alt="" class="img-circle"  width="100" height="100" /> '?>
                                 
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading"> <?php echo $login_session?> </h4>
                                        <h5>Developer & Designer</h5>

                                    </div>
                                </div>
                                <hr />
                                <h5><strong>Personal Bio : </strong></h5>
                               <h4><?php echo $login_email?><h4>
                                <hr />
                                <a href="#" class="btn btn-info btn-sm">Full Profile</a>&nbsp; <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>

								</div>
							</li>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <?php if($adminflag==1){?>
    <div id="wrapper">

       
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
          
              
                
                <li>
                <form action="create_quiz.php" method="post" ><input type="text" id="a" name="a" value="dsadasd.php" style="display:none" >

				</input><input name="submit" STYLE="color: red" value="Create Quiz" type="submit" class="btn btn-default"></input></form>
                </li>
                
                 <li>
                <form action="update_quiz.php" method="post" ><input type="text" id="a" name="a" value="dsadasd.php" style="display:none" >

				</input><input name="submit" STYLE="color: red" value="Update Quiz" type="submit" class="btn btn-default"></input></form>
                </li>
                
                 <li>
                <form action="delete_quiz.php" method="post" ><input type="text" id="a" name="a" value="dsadasd.php" style="display:none" >

				</input><input name="submit" STYLE="color: red" value="Delete Quiz" type="submit" class="btn btn-default"></input></form>
                </li>
               
                <li>
                    <a href="#">Special Pages</a>
                </li>
                <li>
                    <a href="#">Import</a>
                </li>
                <li>
                    <a href="#">Export</a>
                </li>
                
            </ul>
        </div>
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Toggle Menu</a>
                    </div>
            </div>
        </div>
     </div><?PHP } ?><h1><video width="320" height="240" controls>  <source src="uploads/2015-04-18-164200.webm" type="video/mp4"> </video></h1><?php if($adminflag){ ?> <form action="createpage1.php" method="post" ><input type="text" id="a" name="a" value="dsadasd.php" style="display:none" >
</input><input type="text" id="b" name="b" value="~" style="display:none" >
</input><input name="submit" STYLE="color: red" value="edit" type="submit" class="btn btn-default" ></input></form><?php }?>
<br>
<h1><video width="320" height="240" controls>  <source src="uploads/'Share A Coke' campaign ...Coca Cola, a marketing genius!!!.mp4" type="video/mp4"> </video></h1><?php if($adminflag){ ?> <form action="createpage1.php" method="post" ><input type="text" id="a" name="a" value="dsadasd.php" style="display:none" >
</input><input type="text" id="b" name="b" value="~~" style="display:none" >
</input><input name="submit" STYLE="color: red" value="edit" type="submit" class="btn btn-default" ></input></form><?php }?>
<br><h1><img src="http://localhost/newedupedia/uploads/Screenshot%20from%202015-05-23%2017:00:06.png" width="100px" height="100px"</h1><?php if($adminflag){ ?> <form action="createpage1.php" method="post" ><input type="text" id="a" name="a" value="dsadasd.php" style="display:none" >
</input><input type="text" id="b" name="b" value="~~~" style="display:none" >
</input><input name="submit" STYLE="color: red" value="edit" type="submit" class="btn btn-default" ></input></form><?php }?>
<br>
<h1><video width="320" height="240" controls>  <source src="uploads/vlc-record-2014-11-15-14h00m16s-Rememebr The Titans - YIFY-.mp4" type="video/mp4"> </video></h1><?php if($adminflag){ ?> <form action="createpage1.php" method="post" ><input type="text" id="a" name="a" value="dsadasd.php" style="display:none" >
</input><input type="text" id="b" name="b" value="~~~~" style="display:none" >
</input><input name="submit" STYLE="color: red" value="edit" type="submit" class="btn btn-default" ></input></form><?php }?>
<br> 
		 <?PHP if($adminflag!=1){ ?>
		<form action="quiz.php" method="post" ><input type="text" id="a" name="a" value="dsadasd.php" style="display:none" >
		</input><input type="text" id="b" name="b" value="" style="display:none" >
		</input><input name="submit" STYLE="color: red" value="Take quiz" type="submit" class="btn btn-default" ></input></form>
     <?php } ?><script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>
    </body>
    </html>