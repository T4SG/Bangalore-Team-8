<?php
$cid=$_POST['Course_Id'];
$connection = mysql_connect("localhost", "root", "root");
$db = mysql_select_db("edupedia", $connection);
$sql=mysql_query("select *from course where cid='$cid'",$connection);
$row=mysql_fetch_assoc($sql);
$file = $row['course_image'];

if (!unlink($file))
  {
  echo ("Error deleting $file image");
  }
else
  {
  echo ("Deleted $file");
  }
  mysql_query("delete from course where cid='$cid'",$connection);
  $sql=mysql_query("select * from $cid",$connection);
  
  while($row=mysql_fetch_assoc($sql))
  {
	$les=$row['lesson_name'];
	$quizid=$row['quizid'];
	mysql_query("delete from lesson where lesson_name='$les'",$connection);
	  if (!unlink($les.'.php'))
	  {
	  echo ("Error deleting $file lesson");
	  }
	else
	  {
	  echo ("Deleted". $les.".php");
	  }
	  
	  if (!unlink('extras/'.$les.'.php'))
	  {
	  echo ("Error deleting $file lesson");
	  }
	else
	  {
	  echo ("Deleted". $les.".php");
	  }
	  mysql_query("delete from quiz where quiz_id='$quizid'",$connection);
	  mysql_query("drop table $quizid",$connection);	
  }
    mysql_query("drop table $cid",$connection);
    echo '<META HTTP-EQUIV="Refresh" Content="0; URL=course.php">';

?>
