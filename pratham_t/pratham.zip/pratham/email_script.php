<?php
$from="sandeep@gmail.com";
$email=$_POST['email'];
$subject="password Recovery";
$message="qwerty";
mail($email,$subject,$message,"FROM:".$from);
print "your </br>$email</br>$subject</br>$message";
?>

