<?php
echo "<h1><center style=\"color:green\">Correct answers</center></h1>";
session_start();
include('session.php');
$email=$login_email;
$connection = mysql_connect("localhost", "root", "root");
$db = mysql_select_db("edupedia", $connection);
$cid=$_POST['b'];
$les=$_POST['a'];
$pos = strpos($les,".php");
$lesname=substr($les,0,$pos);
$ses_sql=mysql_query("select * from course", $connection);
$ses_sql1=mysql_query("select quizid from $cid where lesson_name='$lesname'",$connection);
$row2=mysql_fetch_assoc($ses_sql1);
$qid=$row2['quizid'];
$ses_sql1=mysql_query("select * from question where queid in(select qid from $qid)",$connection);

$tocount=$_POST['tocount'];
$co=1;
$total_count=0;
$count=0;
$score=0;
while($row2=mysql_fetch_assoc($ses_sql1))
{
	$total_count+=1;	
	$count+=1;	
	echo "<h2>".$count.":".$row2['quename']."</h2>";
	$opt=$row2['Options'];
	$intpos=0;
	$start=0;
	$pos = strpos($opt,";",$intpos);
	$ch=$_POST[$co];
	$ans=$row2['Answers'];
	if($ch==$ans)
	{
		$score+=1;
	}
	$co+=1;	
	while(!$pos==false)
	{
		$o=substr($opt,$start,$pos-$start);	
		if($o==$ans)
		{							
		echo "<h4 style=\"color:green;\">$o</h4>";
		}
		else
		{
			if($o==$ch)
			{
			echo "<h4 style=\"color:red;\">$o</h4>";
			}
			else
			{
			echo "<h4>$o</h4>";
			}
		}
									
		$intpos=$pos+1;
		$start=$pos+1;
		$pos=strpos($opt,";",$intpos);
	}
	$o=substr($opt,$start,strlen($opt));
	if($o==$ans)
		{							
		echo "<h4 style=\"color:green;\">$o</h4>";
		}
		else
		{
			if($o==$ch)
			{
			echo "<h4 style=\"color:red;\">$o</h4>";
			}
			else
			{
			echo "<h4>$o</h4>";
			}
		}
	
 }
 echo "<br><br><h4 style=\"color:blue;\">"."Your Score is:".$score."/".$total_count."</h4>";
 $sql_check=mysql_query("select * from scores where email='$email' and course_id='$cid' and quiz_id='$qid'",$connection);
 $rows = mysql_num_rows($sql_check);
 if($rows==1)
 {
	 mysql_query("update scores set score='$score',total='$total_count' where email='$email' and course_id='$cid' and quiz_id='$qid'",$connection); 
 }
 else{
 $_sessql=mysql_query("insert into scores values('$email','$cid','$qid','$score','$total_count')",$connection);
}
 echo "<a href=\"".$_SESSION['qles']."\">continue</a>";
?>
