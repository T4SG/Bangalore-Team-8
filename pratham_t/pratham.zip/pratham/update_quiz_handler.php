<?php
session_start();
$connection=mysql_connect("localhost","root","root");

$db = mysql_select_db("edupedia", $connection);
$qid=$_POST['qid'];
$qname=$_POST['qname'];
$noq=$_POST['noq'];
$st=$_POST['st'];
$et=$_POST['et'];
$duration=$_POST['duration'];
$date=$_POST['date'];
echo "update quiz set quiz_name='$qname', noq='$noq',start_time='$st', end_time='$et', duration='$duration' date='$date' where quiz_id='$qid'";
$sql=mysql_query("update quiz set quiz_name='$qname', noq='$noq',start_time='$st', end_time='$et', duration='$duration', date='$date' where quiz_id='$qid'",$connection);
echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$_SESSION['quizles'].'.php">';
?>
