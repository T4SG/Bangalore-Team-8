<?php
session_start();
$imgflag='none';
$logflag='visible';
if(isset($_SESSION['login_user'])){
$imgflag='visible';	
$logflag='none';
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>PRATHAM</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
	 <link href="assets/css/grayscale.css" rel="stylesheet" />
</head>
<body>
  
    <section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
						<ul id="menu-top" class="nav navbar-nav navbar-left">
							<div class="media">
                               <!--<a class="media-left" href="#">
                                    <img src="logo-tab.jpg" class="img-thumbnail" alt="logo" width="120" height="20">
                               </a>-->
							</div>	
						</ul>
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
							<li><a class="menu-top-active" href="index.php">Welcome</a></li>
                            <li><a href="course.php">Courses</a></li>
                            <li><a href="login.php" style="display:<?php echo $logflag?>;">Login</a></li> 
							<li><a href="registration.php" style="display:<?php echo $logflag?>;">Registration</a></li> 
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- MENU SECTION END-->
	
	 <!-- Intro Header -->
    <header class="intro">
        <div class="intro-body">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <h1 style="color:white" class="brand-heading"><font color="" >PRATHAM</font></h1>
                        <p class="intro-text"><font color="white" >Find all the courses here.<br>Enjoy Learning!</font></p>
                    </div>
					
					
                </div>
            </div>
        </div>
		<div class="row">
            </div>
    </header>
    <script src="assets/js/jquery-1.11.1.js"></script>
    <script src="assets/js/bootstrap.js"></script>
	<script src="assets/js/grayscale.js"></script>
</body>
</html>
