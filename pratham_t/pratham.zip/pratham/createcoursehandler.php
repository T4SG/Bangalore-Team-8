<?php
	session_start(); // Starting Session
	$error=''; // Variable To Store Error Message
	if (isset($_POST['submit'])) {
	header("location:course.php");
	if (empty($_POST['cid']) || empty($_POST['cname']) ||  empty($_FILES["uploadedimage"]["name"]) || empty($_POST['cdesc']) ||        empty($_POST['cdur']) || empty($_POST['credits'])) {
	$error = "Some fields are empty";
	if(empty($_FILES["uploadedimage"]["name"]))
	{
		$error = "hello image is empty";
	}
}
	else
	{
	// Define $username and $password
	$cid=$_POST['cid'];
	$coursename=$_POST['cname'];
	//echo $coursename;
	$coursedescription=$_POST['cdesc'];
$courseduration=$_POST['cdur'];
$coursecredits=$_POST['credits'];

	
	// Establishing Connection with Server by passing server_name, user_id and password as a parameter
	$connection = mysql_connect("localhost", "root", "root");
	// To protect MySQL injection for Security purpose
	$cid= stripslashes($cid);
	$coursename= stripslashes($coursename);
	$coursedescription= stripslashes($coursedescription);
$courseduration = stripslashes($courseduration);
$coursecredits = stripslashes($coursecredits);


	
	$cid = mysql_real_escape_string($cid);
	$coursename= mysql_real_escape_string($coursename);
	$coursedescription=mysql_real_escape_string($coursedescription);
$courseduration=mysql_real_escape_string($courseduration);
$coursecredits = mysql_real_escape_string($coursecredits);
	
	
	$db = mysql_select_db("edupedia", $connection);
	$sql=mysql_query("select * from course where cid='$cid'",$connection);
	$row=mysql_num_rows($sql);
	if($row!=1)
	{
		echo "****".$row;
	
	function GetImageExtension($imagetype)
	{
	if(empty($imagetype)) return false;
	switch($imagetype)
	{
	case 'image/bmp': return '.bmp';
	case 'image/gif': return '.gif';
	case 'image/jpeg': return '.jpg';
	case 'image/png': return '.png';
	default: return false;
	}
	}
	
	
	
	if (!empty($_FILES["uploadedimage"]["name"])) {
	
	$file_name=$_FILES["uploadedimage"]["name"];
	$temp_name=$_FILES["uploadedimage"]["tmp_name"];
	$imgtype=$_FILES["uploadedimage"]["type"];
	$ext= GetImageExtension($imgtype);
	$imagename=date("d-m-Y")."-".time().$ext;
	$target_path = "images/".$imagename;
	
	
	if(move_uploaded_file($temp_name, $target_path)) {
	
	
	
	mysql_query("insert into course values('$cid','$coursename','".$target_path."','$coursedescription','$courseduration','$coursecredits')",$connection);
	mysql_query("create table $cid(lesson_name varchar(50) primary key,quizid varchar(40))");
	//header("Location: course.php"); // Redirecting To Other Page
	// echo '<META HTTP-EQUIV="Refresh" Content="0; URL=course.php">';
	//header("location: login.php");
	
	echo "hello";
	
	}else{
	
	exit("Error While uploading image on the server");
	} 
	
	}
	
	// Selecting Database
	
	mysql_close($connection); // Closing Connection
	}
	else
	{
		echo "course id already exists. Please choose different course id";
	}
}
	}
	?>
