<?php
if(is_array($_FILES)) {
if(is_uploaded_file($_FILES['userImage']['tmp_name'])) {
$sourcePath = $_FILES['userImage']['tmp_name'];
$targetPath = "uploads/".$_FILES['userImage']['name'];
if (file_exists($targetPath)) {
    echo "<h5 style=\"color:red\">The image with same name already exists</h5>";
} 
else if(move_uploaded_file($sourcePath,$targetPath)) {
?>
<img id="myImg" src="<?php echo $targetPath; ?>" width="100px" height="100px" />
<?php
}
}
}
?>
