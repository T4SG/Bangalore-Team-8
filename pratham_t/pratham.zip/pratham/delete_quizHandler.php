	<?php
	
session_start(); // Starting Session
$connection = mysql_connect("localhost", "root", "root");
$db = mysql_select_db("edupedia", $connection);
$_SESSION['qid']=$_POST['Quiz_Id'];
$qid=$_POST['Quiz_Id'];
//echo $quid;
$error=''; // Variable To Store Error Message
//$id=$_POST['quiz_id'];

//echo 
if (isset($_POST['submit'])) {
		echo "Hello";
	if ( empty($_POST['Quiz_Id'])) {
	$error = "Some fields are empty";
	echo "some fields are empty";
}
	else
	{
	$connection = mysql_connect("localhost", "root", "root");
$db = mysql_select_db("edupedia", $connection);

		
	mysql_query("delete from quiz where quiz_id='$qid'",$connection);
	mysql_query("drop table $qid",$connection);
	 echo '<META HTTP-EQUIV="Refresh" Content="0; URL=course.php">';	
	
	// Selecting Database
	
	mysql_close($connection); // Closing Connection
	}	
	}
	?>
	