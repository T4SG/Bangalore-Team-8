<?php
$cid=$_POST['cid'];
$cname=$_POST['cname'];
$cdesc=$_POST['cdesc'];
$credits=$_POST['credits'];
$cdur=$_POST['cdur'];
$connection = mysql_connect("localhost", "root", "root");
$db = mysql_select_db("edupedia", $connection);
$sql=mysql_query("update course set course_name='$cname', course_desc='$cdesc',course_dur='$cdur',course_credits='$credits' where cid='$cid'",$connection);
//echo "update course set course_name='$cname', course_desc='$cdesc',course_dur='$cdur',course_credits='$credits' where cid='$cid'";
echo '<META HTTP-EQUIV="Refresh" Content="0; URL=course.php">';
?>
