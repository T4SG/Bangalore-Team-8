<?php

session_start();
$connection = mysql_connect("localhost", "root", "root");
$db = mysql_select_db("edupedia", $connection);
$les=$_POST['a'];
$pos = strpos($les,".php");

$lesname1=substr($les,0,$pos);
$ci=$_POST['b'];

$sql=mysql_query("select quizid from $ci where lesson_name ='$lesname1'",$connection);
$row=mysql_fetch_assoc($sql);
$qid=$row['quizid'];
mysql_query("delete from quiz where quiz_id='$qid'",$connection);

mysql_query("drop table $qid",$connection);
mysql_query("update $ci set quizid='0' where lesson_name='$lesname1'",$connection);

//echo "select quiz_name from quiz where quiz_id ='$qid'";
echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$lesname1.'.php">';

?>
