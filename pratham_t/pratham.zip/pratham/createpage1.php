<?php
$handler="createpagehandler.php";
session_start();
$imgflag='none';
$logflag='visible';
$adminflag=0;
if(isset($_SESSION['login_user'])){

$imgflag='visible';	
$logflag='none';
include('session.php');
	if(!strcmp($login_session,"admin"))
	{
		$adminflag=1;
	}
}

if (isset($_POST['submit'])) 
{
$lesname=$_POST['a'];
$identifier=$_POST['b'];
$pos = strpos($lesname,".php");
$lesname1=substr($lesname,0,$pos);
$myfile = fopen('extras/'.$lesname, "r") or die("Unable to open file!");
$content= fread($myfile,filesize($lesname));
$temp="";
$temp1="";
$tx="";

$content=str_replace("~","",$content);
$identifier=str_replace("*","~",$identifier);
$intpos=0;
$wflag=1;
$pos=0;
$p=0;
$t1=0;
$stlen=strlen($identifier);
while($wflag)
{
	$pos=strpos($content,"<h1>",$intpos);
	if($pos===false)
	{
		$wflag=0;
	}
	else
	{
		$p=$p+1;
		if($p===$stlen)
		{
			//echo "asjahsj".$p.":::".$stlen."::".$pos;
			if($pos>0)
			{
				//echo "true";
				$temp=substr($content,0,$pos);
			}
			else
			{
				//echo "false";
			}
			//echo "intpos:".$intpos;
			
			$intpos=$intpos+($pos-$intpos)+4;
			//echo "intpos*:".$intpos;
			$pos1=$pos;
			$pos=strpos($content,"<h1>",$intpos);
			//echo "pos:".$pos;
			if($pos===false)
			{
				//echo "^^^";
				$tx=substr($content,$pos1,strlen($content));
			}
			else
			{
				//echo "true1";
				//echo "pos1:".$pos1."pos:".$pos;
				$tx=substr($content,$pos1,$pos-$pos1);
				//echo substr($content,$pos1,$pos);
				//echo $tx;	
				$temp1=substr($content,$pos,strlen($content)-$pos);
				//echo $temp1;
			}
			$wflag=0;
		}
		$intpos=$intpos+($pos-$intpos)+4;
		//echo "last:intpos:".$intpos;
	}	
}




fclose($myfile);
$handler="updatepagehandler.php";
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8" />
<meta name="viewport"
	content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
<title>Create lesson</title>
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
 <link href="styles.css" rel="stylesheet" type="text/css" />
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript">
$(document).ready(function (e) {
	$("#uploadForm").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "upload.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
			$("#targetLayer").html(data);
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
<script>
/* Script written by Adam Khoury @ DevelopPHP.com */
/* Video Tutorial: http://www.youtube.com/watch?v=EraNFJiY0Eg */
function _(el){
	return document.getElementById(el);
}
function uploadFile(){
	var file = _("file1").files[0];
	// alert(file.name+" | "+file.size+" | "+file.type);
	var formdata = new FormData();
	formdata.append("file1", file);
	var ajax = new XMLHttpRequest();
	ajax.upload.addEventListener("progress", progressHandler, false);
	ajax.addEventListener("load", completeHandler, false);
	ajax.addEventListener("error", errorHandler, false);
	ajax.addEventListener("abort", abortHandler, false);
	ajax.open("POST", "file_upload_parser.php");
	ajax.send(formdata);
}



function uploadFile1(){
	var file = _("file2").files[0];
	// alert(file.name+" | "+file.size+" | "+file.type);
	var formdata = new FormData();
	formdata.append("file2", file);
	var ajax = new XMLHttpRequest();
	ajax.upload.addEventListener("progress", progressHandler1, false);
	ajax.addEventListener("load", completeHandler1, false);
	ajax.addEventListener("error", errorHandler1, false);
	ajax.addEventListener("abort", abortHandler1, false);
	ajax.open("POST", "file_upload_parser1.php");
	ajax.send(formdata);
}

function progressHandler1(event){
	_("loaded_n_total1").innerHTML = "Uploaded "+event.loaded+" bytes of "+event.total;
	var percent = (event.loaded / event.total) * 100;
	_("progressBar1").value = Math.round(percent);
	_("status1").innerHTML = Math.round(percent)+"% uploaded... please wait";
}
function completeHandler1(event){
	_("status1").innerHTML = event.target.responseText;
	_("progressBar1").value = 0;
}
function errorHandler1(event){
	_("status1").innerHTML = "Upload Failed";
}
function abortHandler1(event){
	_("status1").innerHTML = "Upload Aborted";
}

function progressHandler(event){
	_("loaded_n_total").innerHTML = "Uploaded "+event.loaded+" bytes of "+event.total;
	var percent = (event.loaded / event.total) * 100;
	_("progressBar").value = Math.round(percent);
	_("status").innerHTML = Math.round(percent)+"% uploaded... please wait";
}
function completeHandler(event){
	_("status").innerHTML = event.target.responseText;
	_("progressBar").value = 0;
}
function errorHandler(event){
	_("status").innerHTML = "Upload Failed";
}
function abortHandler(event){
	_("status").innerHTML = "Upload Aborted";
}
</script>
<script>
/*function bold1() {
	var x = document.getElementById("myTextarea").value;
	document.getElementById("myTextarea").value=x+"\n<b>Enter text here</b>";
}*/
function getSel() // javascript
{
    // obtain the object reference for the <textarea>
    var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    var sel = txtarea.value.substring(start, finish);
    // do something with the selected content
}
function bold1() {
    var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    var sel = txtarea.value.substring(start, finish); 
    if(sel=="")
    {
		sel="add text here";
	}    
        var myvalue="<b>"+sel+"</b><br>\n";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}
function italic1(){
	
	var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    var sel = txtarea.value.substring(start, finish); 
    if(sel=="")
    {
		sel="add text here";
	}    
        var myvalue="<i>"+sel+"</i><br>\n";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}
function center(){
	
	var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    var sel = txtarea.value.substring(start, finish); 
    if(sel=="")
    {
		sel="add text here";
	}    
        var myvalue="<centre>"+sel+"</centre><br>\n";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}
function pre(){

	var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    var sel = txtarea.value.substring(start, finish); 
    if(sel=="")
    {
		sel="add text here";
	}    
        var myvalue="<pre style=\"width:1000px;\">"+sel+"</pre><br>\n";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}
function link1(){
	
		var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    var sel = txtarea.value.substring(start, finish); 
    if(sel=="")
    {
		sel="add text here";
	}    
        var myvalue="<a href src="+sel+"></a>\n<br>";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}
function heading(){
		var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    var sel = txtarea.value.substring(start, finish); 
    if(sel=="")
    {
		sel="add text here";
	}    
      var myvalue="<h1><font color=\"#669999\">"+sel+"</font></h1>\n<br>";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}

function imageup()
{
	var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    var sel = "<img src=\""+document.getElementById("myImg").src+"\" width=\"100px\" height=\"100px\"";
  
    if(sel=="")
    {
		sel="add text here";
	}    
        var myvalue="<h1>"+sel+"</h1>\n<br>";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		//txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}

function breaktag(){
	var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    
        var myvalue="\n<br>";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}
function iframe()
{
	var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    
	var sel="<iframe src=\""+document.getElementById("ifm").value+"\" width=\"420\" height=\"345\">  <p>Your browser does not support iframes.</p></iframe>";
    if(sel=="")
    {
		sel="add text here";
	}    
        var myvalue=sel+"\n<br>";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		//txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}
function hr1(){
	var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    
        var myvalue="\n<hr><br>";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}
function tablestart1(){
	var txtarea = document.getElementById("myTextarea");
	var row=document.getElementById("tr").value;
	var col=document.getElementById("tc").value;
	var width=document.getElementById("tw").value;
	var height=document.getElementById("th").value;
	var val="<table ";
	if(height!="" || width!="")
	{
		val+="style=\"height:"+height+"px; width:"+width+"px\">";
	}
	val+="\n<tbody>";
	while(row!="0")
	{
		row-=1;
		val+="\n<tr>";
		while(col!="0")
		{
			val+="\n<td>&nbsp;</td>";
			col-=1;
		}
		 col=document.getElementById("tc").value;
		val+="\n</tr>";
	}
	val+="\n</tbody>\n</table>";
	
	  var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
	txtarea.value= txtarea.value.substring(0, start)+val+txtarea.value.substring(finish, txtarea.value.length)+"<br>";
		txtarea.setSelectionRange(start+val.length, start+val.length);
}

function fileup()
{
	var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    
	var sel="<pre><a href=\"uploads/"+document.getElementById("status1").innerHTML+"\" download=\""+document.getElementById("status1").innerHTML+"\">"+document.getElementById("status1").innerHTML+" </a></pre>";
    if(sel=="")
    {
		sel="add text here";
	}    
        var myvalue=sel+"\n<br>";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		//txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}

function vedio()
{
	var txtarea = document.getElementById("myTextarea");
    // obtain the index of the first selected character
    var start = txtarea.selectionStart;
    // obtain the index of the last selected character
    var finish = txtarea.selectionEnd;
    // obtain the selected text
    
	var sel="<video width=\"320\" height=\"240\" controls>  <source src=\"uploads/"+document.getElementById("status").innerHTML+"\" type=\"video/mp4\"> </video>";
    if(sel=="")
    {
		sel="add text here";
	}    
        var myvalue=sel+"\n<br>";
      //txtarea.value = txtarea.value.substring(0, start) + sel + txtarea.value.substring(finish, txtarea.value.length)+"hai";
     // txtarea.setSelectionRange(finish+myValue.length, finish+myValue.length);
     txtarea.value= txtarea.value.substring(0, start)+myvalue+txtarea.value.substring(finish, txtarea.value.length);
		//txtarea.setSelectionRange(start+myValue.length, start+myValue.length);
}
</script>
</head>
<body>

	<section class="menu-section" >
        <div class="container">
            <div class="row" >
                <div class="col-md-12" >
                    <div class="navbar-collapse collapse ">
						<ul id="menu-top" class="nav navbar-nav navbar-left">
							<div class="media">
                               <a class="media-left" href="#">
                                    <img src="logo-tab.jpg" class="img-thumbnail" alt="logo" width="120" height="20">
                               </a>
							</div>	
						</ul>
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
							<li><a  href="index.php">Welcome</a></li>
                            <li><a class="menu-top-active" href="course.php">Courses</a></li>
                            <li><a href="login.php"style="display:<?php echo $logflag?>;">Login</a></li> 
							<li><a href="registration.php"style="display:<?php echo $logflag?>;">Registration</a></li> 
							<li class="dropdown" style="display:<?php echo $imgflag?>;">
								<a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
									<span class="glyphicon glyphicon-user" style="font-size: 15px;"></span>
								</a>
								<div class="dropdown-menu dropdown-settings">
                                <div class="media">
                                    <a class="media-left" href="#">
                                  <?php echo '<img src="'. $login_image.'" alt="" class="img-circle"  width="100" height="100" /> '?>
                                 
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading"> <?php echo $login_session?> </h4>
                                        <h5>Developer & Designer</h5>

                                    </div>
                                </div>
                                <hr />
                                <h5><strong>Personal Bio : </strong></h5>
                               <h4><?php echo $login_email?><h4>
                                <hr />
                                <a href="#" class="btn btn-info btn-sm">Full Profile</a>&nbsp; <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>

								</div>
							</li>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    
	<!-- MENU SECTION END-->	
	<div class="content-wrapper">
		<div class="container">
	            <form action="createpagehandler1.php"  enctype="multipart/form-data"  method="post" role="form">
				<div class="form-group">
				<label for="usr">Lessonname:</label>
				<input type="text" class="form-control" id="usr" name="lessonname" value="<?php echo $lesname1 ?>" placeholder="Enter lesson name without extension" required>
				</div>
				
			
			<button id="bold" name="bubold" type="button" class="btn btn-info"  onclick="bold1(document.getElementById('myTextarea'),'hello')">Bold</button>
			<button id="italic" name="buitalic" type="button" class="btn btn-info"  onclick="italic1()" >Italic</button>
			<button id="pretag" name="bupretag" type="button" class="btn btn-info"  onclick="pre()">Pre tag</button>
			<button id="image" name="imageupload" type="button" class="btn btn-info"  data-toggle="modal" data-target="#im" >Image</button>
			 
			<button id="br" name="break" type="button" class="btn btn-info" onclick="breaktag()">Break</button>
			
			
			<button type="button" class="btn btn-info"  data-toggle="modal" data-target="#tl">table</button>
										 <div class="modal fade" id="tl" role="dialog">
										<div class="modal-dialog">
		
											<div class="modal-content">
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal">&times;</button>
													<h4 class="modal-title">table</h4>
												</div>
												
												<div class="modal-body">													
													<div class="col-lg-2">
														<label>row</label>
														<input type="text" id="tr" class="form-control" placeholder="number">
													</div>
													<div class="col-lg-2">
														<label>column</label>
														<input type="text" id="tc" class="form-control" placeholder="number">
													</div>
													<div class="col-lg-2">
														<label>width</label>
														<input type="text" id="tw" class="form-control" placeholder="number">
													</div>
													<div class="col-lg-2">
														<label>height</label>
														<input type="text" id="th" class="form-control" placeholder="number">
													</div>
											  </div>
												<div class="modal-footer">
													
													<button id="tabstart" name="tablestart" type="button"  class="btn btn-default" data-dismiss="modal" onclick="tablestart1()">ok</button>
												</div>
												
											</div>
										</div>
									</div>
			
			
			
			<button id="hrline" name="hr" type="button" class="btn btn-success" onclick="hr1()">hr</button>
			<button id="link" name="a href" type="button" class="btn btn-success" onclick="link1()">a href</button>		
			
			<button id="h1" name="mainheader" type="button" class="btn btn-success"  onclick="heading()">Main heading</button>
			
			<button id="centertag" name="bucentertag" type="button" class="btn btn-success" onclick="center()" >Center tag</button>
			<button id="file" name="fileupload" type="button" class="btn btn-warning" data-toggle="modal" data-target="#fl" >Fileupload</button>
			<button id="file" name="fileupload" type="button" class="btn btn-warning" data-toggle="modal" data-target="#ve"  >video</button>
			<button id="file" name="fileupload" type="button" class="btn btn-warning" data-toggle="modal" data-target="#if"  >iframe</button>
			<br>
			<textarea class="form-control" rows="20" id="myTextarea1" name="txtarea1" style="display:none;" ><?php echo $temp ?></textarea>
			<textarea class="form-control" rows="20" id="myTextarea" name="txtarea" ><?php echo $tx ?></textarea>
			<textarea class="form-control" rows="20" id="myTextarea2" name="txtarea2"   style="display:none;"><?php echo $temp1?></textarea>
			<hr>
			
	                <input name="submit" value="save" type="submit" class="btn btn-primary">
			<input name="preview" value="preview" type="submit" class="btn btn-success"formtarget="_blank">
			<span style="color:red"><?php echo $error; ?></span>
       	          </form>
       	          
       	         <div class="modal fade" id="im" role="dialog">
										<div class="modal-dialog">
		
											<div class="modal-content">
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal">&times;</button>
													<h4 class="modal-title">image</h4>
												</div>
												
												<div class="modal-body">													
													<div class="bgColor">
														<form id="uploadForm" action="upload.php" method="post">
														<div id="targetLayer">No Image</div>
														<div id="uploadFormLayer">
														<label>Upload Image File:</label><br/>
														<input name="userImage" id="itl" type="file" class="inputFile" />
														<input type="submit" value="Submit" class="btnSubmit" />
														</form>
														</div>
														</div>
											  </div>
												<div class="modal-footer">
													
													<button id="img" name="img" type="button"  class="btn btn-default" data-dismiss="modal" onclick="imageup()">ok</button>
												</div>
												
											</div>
										</div>
									</div>
									
									
									
									<div class="modal fade" id="ve" role="dialog">
										<div class="modal-dialog">
		
											<div class="modal-content">
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal">&times;</button>
													<h4 class="modal-title">Video</h4>
												</div>
												
												<div class="modal-body">													
													
													<form id="upload_form" enctype="multipart/form-data" method="post">
													  <input type="file" name="file1" id="file1"><br>
													  <input type="button" value="Upload File" onclick="uploadFile()">
													  <progress id="progressBar" value="0" max="100" style="width:300px;"></progress>
													  <h1 id="status"></h1>
													  <p id="loaded_n_total"></p>
													</form>
												</div>
												<div class="modal-footer">
													
													<button id="img" name="img" type="button"  class="btn btn-default" data-dismiss="modal" onclick="vedio()">ok</button>
												</div>
												
											</div>
										</div>
									</div>
									
									
									
									<div class="modal fade" id="fl" role="dialog">
										<div class="modal-dialog">
		
											<div class="modal-content">
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal">&times;</button>
													<h4 class="modal-title">File Upload</h4>
												</div>
												
												
												<div class="modal-body">													
													
													<form id="upload_form1" enctype="multipart/form-data" method="post">
													  <input type="file" name="file2" id="file2"><br>
													  <input type="button" value="Upload File" onclick="uploadFile1()">
													  <progress id="progressBar1" value="0" max="100" style="width:300px;"></progress>
													  <h1 id="status1"></h1>
													  <p id="loaded_n_total1"></p>
													</form>
												</div>
												<div class="modal-footer">
													
													<button id="img" name="img" type="button"  class="btn btn-default" data-dismiss="modal" onclick="fileup()">ok</button>
												</div>
												
											</div>
										</div>
									</div>
									
									
									
									<div class="modal fade" id="if" role="dialog">
										<div class="modal-dialog">
		
											<div class="modal-content">
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal">&times;</button>
													<h4 class="modal-title">Iframe</h4>
												</div>
												
												<div class="modal-body">													
													<label>URL</label>
														<input type="text" id="ifm" class="form-control" placeholder="Enter Link">
												</div>
												<div class="modal-footer">
													
													<button id="img" name="img" type="button"  class="btn btn-default" data-dismiss="modal" onclick="iframe()">ok</button>
												</div>
												
											</div>
										</div>
									</div>
									
									
									
		</div>
	</div>
	<!-- CONTENT-WRAPPER SECTION END-->
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					&copy; 2015 YourCompany | By : <a
						href="http://www.designbootstrap.com/" target="_blank">DesignBootstrap</a>
				</div>
			</div>
		</div>
	</footer>
	<!-- FOOTER SECTION END-->
	<!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
	<!-- CORE JQUERY SCRIPTS -->
	<script src="assets/js/jquery-1.11.1.js"></script>
	<!-- BOOTSTRAP SCRIPTS  -->
	<script src="assets/js/bootstrap.js"></script>
</body>
</html>
