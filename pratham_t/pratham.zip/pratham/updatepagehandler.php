<?php
session_start(); // Starting Session
echo $_POST['txtarea'];
$lessonname=$_POST['lessonname'];
$myfile = fopen($lessonname, "w") or die("Unable to open file!");
$txt = $_POST['txtarea'];
echo $txt;
fwrite($myfile, $txt);
fclose($myfile);

?>
