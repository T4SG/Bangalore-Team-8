<?php
session_start(); 
$qid=$_SESSION['q'];
$connection = mysql_connect("localhost", "root", "root");
$db = mysql_select_db("edupedia", $connection);

 foreach($_POST['question'] as $value)
{
echo $value.":\n";
echo "select queid from question where quename='$value'";
$sql1=mysql_query("select queid from question where quename='$value'",$connection);
//$sql1=mysql_query("insert into $id values")
$row = mysql_fetch_assoc($sql1);
$qtid=$row['queid'];
echo $qtid."::";
mysql_query("insert into $qid values('$qtid')",$connection);
}
mysql_close($connection); 
echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$_SESSION['quizles'].'.php">';
?>
