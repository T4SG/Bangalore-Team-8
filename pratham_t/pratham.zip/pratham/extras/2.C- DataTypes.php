<h1>Introduction to Data    Types</h1>
<pre style="width:1000px;">In the C programming language, data types refer to an extensive system used for declaring variables or functions of different 
types. The type of a variable determines how much space it occupies in storage and how the bit pattern stored is interpreted.

The types in C can be classified as follows:
<br>
<table style="height:300px; width:200px" border="1">
<tbody>
<tr>
<td>     <b>S.NO</b>
</td>
<td>           <b>Types  and Description</b>
</td>
</tr>
<tr>
<td>       1.</td>
<td><b>Basic Types:</b>


They are arithmetic types and consists of the two types: (a) integer types and (b) floating-point types.</td>
</tr>
<tr>
<td>     2.</td>
<td><b>Enumerated types:</b>


They are again arithmetic types and they are used to define variables that can only be assigned certain 
discrete integer values throughout the program.</td>
</tr>
<tr>
<td>     3.</td>
<td><b>The type void:</b>


The type specifier void indicates that no value is available.</td>
</tr>
<tr>
<td>     4.</td>
<td><b>Derived types:</b>


They include (a) Pointer types, (b) Array types, (c) Structure types, (d) Union types and (e) Function types.</td>
</tr>
</tbody>
</table>

The array types and structure types are referred to collectively as the aggregate types. The type of a function
specifies the type of the function's return value. We will see basic types in the following section, whereas, other types 
will be covered in the upcoming chapters.

<iframe src="https://www.youtube.com/embed/1jT1BYny5Bs" width="420" height="345">  <p>Your browser does not support iframes.</p></iframe>
</pre><br>