
<h1><font color="#669999">Introduction</font></h1>
<pre style="width: 1000px;">
The C is a general-purpose, procedural, imperative computer programming language developed in 1972 by Dennis M. Ritchie at   the Bell Telephone Laboratories to develop the UNIX operating system.

The C is the most widely used computer language, it keeps fluctuating at number one scale of popularity along with Java programming language, which is also equally popular and most widely used among modern software programmers.
<iframe src="https://www.youtube.com/embed/69cz3BcPLLo" width="420" height="345">  <p>Your browser does not support iframes.</p></iframe>
</pre>
<br>