<h1><font color="#669999">Introduction</font></h1>
<pre>
Java is a high-level programming language originally developed by Sun Microsystems and released in 1995. 
Java runs on a variety of platforms, such as Windows, Mac OS, and the various versions of UNIX. This tutorial 
gives a complete understanding of Java.

This reference will take you through simple and practical approach while learning Java Programming language.
Audience
This reference has been prepared for the beginners to help them understand the basic to advanced concepts related to Java Programming language.
<iframe src="https://www.youtube.com/embed/hf0nombXh44" width="420" height="345">  <p>Your browser does not support iframes.</p></iframe>
</pre>
<br>