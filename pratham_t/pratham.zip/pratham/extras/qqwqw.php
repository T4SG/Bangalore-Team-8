<h1><img src="http://localhost/newedupedia/uploads/update_quiz_handler.php" width="100px" height="100px"</h1>
<br>