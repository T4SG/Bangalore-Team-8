<h1><img src="http://localhost/newedupedia/uploads/2015-02-03-180216_3.jpg" width="100px" height="100px"</h1>

<h1><img src="http://localhost/newedupedia/uploads/2015-02-03-180216_3.jpg" width="100px" height="100px"</h1>
<br>

<h1><img src="http://localhost/newedupedia/uploads/2015-02-03-180216_3.jpg" width="100px" height="100px"</h1>
<br>
<br>
 <iframe width="420" height="315"
src="http://www.youtube.com/embed/XGSy3_Czz8k?autoplay=1">
</iframe> 