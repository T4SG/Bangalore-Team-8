<iframe width="420" height="345"
source src="http://www.youtube.com/embed/XGSy3_Czz8k" type="video/mp4">
</iframe>

<h1><video width="320" height="240" controls>  <source src="http://www.youtube.com/embed/XGSy3_Czz8k" type="video/mp4"> </video></h1>
<br>