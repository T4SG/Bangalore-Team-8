<h1>Hello world program</h1>
<pre style="width:1000px;">

 Before we study basic building blocks of the C programming language, let us look a bare minimum C program structure so that we 
 can take it as a reference in upcoming chapters.
 <b>C Hello World Example</b>

  A C program basically consists of the following parts:

 1.  Preprocessor Commands

 2.  Functions

 3.  Variables

 4.  Statements & Expressions

 5.  Comments

 Let us look at a simple code that would print the words "<b>Hello World</b>":

<b>#include <stdio.h>
int main()
{
   /* my first program in C */
   printf("Hello, World! \n");  
   return 0;
}</b>


 <b>Let us look various parts of the above program:</b>


 1.  The first line of the program #include <stdio.h> is a preprocessor command, which tells a C compiler to 
     include stdio.h file before going to actual compilation.

 2.  The next line int main() is the main function where program execution begins.

 3.  The next line /*...*/ will be ignored by the compiler and it has been put to add additional comments in the program. 
     So such lines are called comments in the program.

 4.  The next line printf(...) is another function available in C which causes the message "Hello, World!" to be 
     displayed on the screen.

 5.  The next line return 0; terminates main()function and returns the value 0.
</pre>
<br>
<h1>hello</h1>

 1.  The first line of the program #include <stdio.h> is a preprocessor command, which tells a C compiler to 
     include stdio.h file before going to actual compilation.

 2.  The next line int main() is the main function where program execution begins.

 3.  The next line /*...*/ will be ignored by the compiler and it has been put to add additional comments in the program. 
     So such lines are called comments in the program.

 4.  The next line printf(...) is another function available in C which causes the message "Hello, World!" to be 
     displayed on the screen.

 5.  The next line return 0; terminates main()function and returns the value 0.
