<h1><font color="#669999">Introduction</font></h1>
<pre>
Database Management System or DBMS in short refers to the technology of storing and retrieving users’ data with utmost 
efficiency along with appropriate security measures. This tutorial explains the basics of DBMS such as its architecture, data models, 
data schemas, data independence, E-R model, relation model, relational database design, and storage and file structure and much more.

<iframe src="https://www.youtube.com/embed/1057YmExS-I" width="420" height="345">  <p>Your browser does not support iframes.</p></iframe>
</pre>
