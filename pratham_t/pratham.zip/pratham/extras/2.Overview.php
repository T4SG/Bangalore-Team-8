<h1>Overview</h1>
<br>
<pre>Java programming language was originally developed by Sun Microsystems which was initiated by James Gosling and released 
in 1995 as core component of Sun Microsystems' Java platform (Java 1.0 [J2SE]).

As of December 2008, the latest release of the Java Standard Edition is 6 (J2SE). With the advancement of Java and its widespread 
popularity, multiple configurations were built to suite various types of platforms. Ex: J2EE for Enterprise Applications, J2ME for Mobile
 Applications.

Sun Microsystems has renamed the new J2 versions as Java SE, Java EE and Java ME respectively. Java is guaranteed to be Write Once,
Run Anywhere.

Java is:

<b>Object Oriented</b>: In Java, everything is an Object. Java can be easily extended since it is based on the Object model.

<b>Platform independent</b>: Unlike many other programming languages including C and C++, when Java is compiled, it is 
not compiled into platform specific machine, rather into platform independent byte code. This byte code is distributed over the 
web and interpreted by virtual Machine (JVM) on whichever platform it is being run.

<b>Simple</b>:Java is designed to be easy to learn. If you understand the basic concept of OOP Java would be easy to master.

<b>Secure</b>: With Java's secure feature it enables to develop virus-free, tamper-free systems. Authentication techniques are based 
on public-key encryption.

<b>Architectural-neutral</b> :Java compiler generates an architecture-neutral object file format which makes the compiled code to be 
executable on many processors, with the presence of Java runtime system.

<b>Portable</b>:Being architectural-neutral and having no implementation dependent aspects of the specification makes Java portable. 
Compiler in Java is written in ANSI C with a clean portability boundary which is a POSIX subset.

<b>Robust</b>:Java makes an effort to eliminate error prone situations by emphasizing mainly on compile time error checking and runtime checking.