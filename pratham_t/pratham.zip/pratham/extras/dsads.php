<h1><img src="http://localhost/newedupedia/uploads/Screenshot%20from%202015-05-23%2016:45:29.png" width="100px" height="100px"</h1>
<br><h1><img src="http://localhost/newedupedia/uploads/unity-launcher_004.png" width="100px" height="100px"</h1>
<br>