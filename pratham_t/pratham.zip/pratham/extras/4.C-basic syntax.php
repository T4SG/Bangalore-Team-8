<h1><font color="#669999">Comments</font></h1>
<pre style="width:1000px;">

Comments are like helping text in your C program and they are ignored by the compiler. They start with /* and terminates with the characters */ as shown below:

<b>/* my first program in C */</b>
You cannot have comments within comments and they do not occur within a string or character literals.
</pre><br>
