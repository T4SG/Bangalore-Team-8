<h1><font color="#669999">Java-Basic Syntax</font></h1>
<pre style="width:1000px;">When we consider a Java program it can be defined as a collection of objects that communicate via invoking each other's methods. Let us now briefly look into what do class, object, methods and instance variables mean.

<b>Object </b>- Objects have states and behaviors. Example: A dog has states - color, name, breed as well as behaviors -wagging, barking, eating. An object is an instance of a class.

<b>Class </b>- A class can be defined as a template/ blue print that describes the behaviors/states that object of its type support.

<b>Methods </b>- A method is basically a behavior. A class can contain many methods. It is in methods where the logics are written, data is manipulated and all the actions are executed.

<b>Instance Variables </b>- Each object has its unique set of instance variables. An object's state is created by the values assigned to these instance variables.

<b>First Java Program:</b>

Let us look at a simple code that would print the words Hello World.

public class MyFirstJavaProgram {

   /* This is my first java program.  
    * This will print 'Hello World' as the output
    */

    public static void main(String []args) {
       System.out.println("Hello World"); // prints Hello World
    }
} 
Let's look at how to save the file, compile and run the program. Please follow the steps given below:

Open notepad and add the code as above.

Save the file as: MyFirstJavaProgram.java.

Open a command prompt window and go o the directory where you saved the class. Assume it's C:\.

Type ' javac MyFirstJavaProgram.java ' and press enter to compile your code. If there are no errors in your code, the command prompt will take you to the next line (Assumption : The path variable is set).

Now, type ' java MyFirstJavaProgram ' to run your program.

You will be able to see ' Hello World ' printed on the window.

C : > javac MyFirstJavaProgram.java
C : > java MyFirstJavaProgram 
Hello World
<b>Basic Syntax:</b>

About Java programs, it is very important to keep in mind the following points.</pre><br>
