<h1>http://localhost/newedupedia/uploads/images.jpg</h1>
<br>