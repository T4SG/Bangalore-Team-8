<h1><img src="http://localhost/newedupedia/uploads/Screenshot%20from%202015-06-03%2022:53:03.png" width="100px" height="100px"</h1>
<br>
<pre><a href="uploads/let us c solutions.pdf" download="let us c solutions.pdf">let us c solutions.pdf </a></pre>
<br><video width="320" height="240" controls>  <source src="uploads/vlc-record-2015-02-28-12h18m52s-Virtual reality -- how the metaverse will change filmmaking - George Bloom - TEDxHollywood.mp4-.mp4" type="video/mp4"> </video>
<br>