<h1><video width="320" height="240" controls>  <source src="uploads/2015-04-18-164200.webm" type="video/mp4"> </video></h1>
<br>
<h1><video width="320" height="240" controls>  <source src="uploads/'Share A Coke' campaign ...Coca Cola, a marketing genius!!!.mp4" type="video/mp4"> </video></h1>
<br><h1><img src="http://localhost/newedupedia/uploads/Screenshot%20from%202015-05-23%2017:00:06.png" width="100px" height="100px"</h1>
<br>
<h1><video width="320" height="240" controls>  <source src="uploads/vlc-record-2014-11-15-14h00m16s-Rememebr The Titans - YIFY-.mp4" type="video/mp4"> </video></h1>
<br>