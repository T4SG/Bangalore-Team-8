<h1><img src="http://localhost/newedupedia/uploads/2015-02-03-180216_2.jpg" width="100px" height="100px"</h1>

<h1><img src="http://localhost/newedupedia/uploads/2015-02-03-182916_3.jpg" width="100px" height="100px"</h1>
<br>

<br>