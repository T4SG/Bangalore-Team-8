	<?php
	session_start(); // Starting Session
	$error=''; // Variable To Store Error Message
	$ci=$_POST['b'];
	$lesname=$_POST['a'];
	
	$pos = strpos($lesname,".php");
	$lesname1=substr($lesname,0,$pos);
	if (isset($_POST['submit'])) {
		echo "hello";
	if (empty($_POST['qid']) || empty($_POST['qname']) || empty($_POST['noq'])  || empty($_POST['st'])|| empty($_POST['et'])|| empty($_POST['duration'])|| empty($_POST['date'])) {
	$error = "Some fields are empty";
	echo "some fields are empty";
	}
	else
	{
	
	/*$cid=$_POST['cid'];
	$lid=$_POST['lid'];*/
	$_SESSION['q']=$_POST['qid'];
	$qid=$_POST['qid'];
	$qname=$_POST['qname'];
	$noq=$_POST['noq'];
	$st=$_POST['st'];
	$et=$_POST['et'];
	$duration=$_POST['duration'];
	$date=$_POST['date'];
	// Establishing Connection with Server by passing server_name, user_id and password as a parameter
	$connection = mysql_connect("localhost", "root", "root");
	// To protect MySQL injection for Security purpose
	/*$cid= stripslashes($cid);
	$lid=stripslashes($lid);*/
	$qid=stripslashes($qid);
	$qname=stripslashes($qname);
	$noq=stripslashes($noq);
	$st=stripslashes($st);
	$et=stripslashes($et);
	$duration=stripslashes($duration);
	$date=stripslashes($date);
	
	/*$cid = mysql_real_escape_string($cid);
	$lid = mysql_real_escape_string($lid);*/
	$qid = mysql_real_escape_string($qid);
	$qname = mysql_real_escape_string($qname);
	$noq = mysql_real_escape_string($noq);
	$st = mysql_real_escape_string($st);
	$et = mysql_real_escape_string($et);
	$duration= mysql_real_escape_string($duration);
	$date=mysql_real_escape_string($date);
		
	
	
	
	$db = mysql_select_db("edupedia", $connection);
	
	mysql_query("insert into quiz values('$qid','$qname','$noq','$st','$et','$duration','$date')",$connection);
       mysql_query("create table $qid(qid varchar(50))");
       mysql_query("update $ci set quizid='$qid' where lesson_name = '$lesname1'"); 
       echo "update table $ci set quizid='$qid' where lesson_name = '$lesname1'";
	 echo '<META HTTP-EQUIV="Refresh" Content="0; URL=add_question.php">';
	
	
	$_SESSION['quizles']=$lesname1;
	
	// Selecting Database
	
	mysql_close($connection); // Closing Connection
	}
	}
	?>
	

